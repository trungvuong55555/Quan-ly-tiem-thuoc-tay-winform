﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace BTLWindow
{
    class BLLQLHoadon
    {
        DAL data = new DAL();

        public void insert(String mahoadon, DateTime date, String matv)
        {
            try
            {
                String sql = "insert into hoadon values('" + mahoadon + "','" + date.ToString("yyyy-MM-dd") + "','" + matv + "')";
                data.ExecNonQuery(sql);
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void update_tongtien(String mahoadon, int tongtien)
        {
            try
            {
                String sql = "update hoadon set tongtien= " + tongtien + " where mahoadon=" + mahoadon + "";
                data.ExecNonQuery(sql);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
