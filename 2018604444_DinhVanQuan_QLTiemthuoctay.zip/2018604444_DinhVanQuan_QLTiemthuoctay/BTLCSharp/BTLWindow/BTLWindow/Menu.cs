﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTLWindow
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void buttonQLNhanvien_Click(object sender, EventArgs e)
        {
            QLnhanvien a = new QLnhanvien();
            this.Hide();
            a.ShowDialog();
        }

        private void buttonQLHang_Click(object sender, EventArgs e)
        {
            QLHang a = new QLHang();
            this.Hide();
            a.ShowDialog();
        }

        private void buttonNhaphang_Click(object sender, EventArgs e)
        {
            QLNhaphang a = new QLNhaphang();
            this.Hide();
            a.ShowDialog();
        }

        private void buttonQLLuongthang_Click(object sender, EventArgs e)
        {
            QLLuongThang a = new QLLuongThang();
            this.Hide();
            a.ShowDialog();
        }

        private void buttonThietlap_Click(object sender, EventArgs e)
        {
            Thietlap a = new Thietlap();
            this.Hide();
            a.ShowDialog();
        }

        private void buttonThongke_Click(object sender, EventArgs e)
        {
            Thongke a = new Thongke();
            this.Hide();
            a.ShowDialog();
        }

        private void buttonThaydoimk_Click(object sender, EventArgs e)
        {
            Thaydoimk a = new Thaydoimk();
            this.Hide();
            a.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            this.Hide();
            a.ShowDialog();
        }
    }
}
