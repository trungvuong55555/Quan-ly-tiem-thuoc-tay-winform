﻿
namespace BTLWindow
{
    partial class Thietlap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxNhancong = new System.Windows.Forms.TextBox();
            this.textBoxDiennuoc = new System.Windows.Forms.TextBox();
            this.textBoxNha = new System.Windows.Forms.TextBox();
            this.textBoxHoahong = new System.Windows.Forms.TextBox();
            this.textBoxKhac = new System.Windows.Forms.TextBox();
            this.buttonQuaylai = new System.Windows.Forms.Button();
            this.buttonThietlap = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.trangChủToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýThànhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýThángLươngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýNhậpHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thiếtLậpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thayĐổiTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(128, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "THIẾT LẬP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Giá nhân công ngày:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tiền điện + nước:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tiền nhà:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 262);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Hoa hồng:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 321);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Khác:";
            // 
            // textBoxNhancong
            // 
            this.textBoxNhancong.Location = new System.Drawing.Point(143, 85);
            this.textBoxNhancong.Name = "textBoxNhancong";
            this.textBoxNhancong.Size = new System.Drawing.Size(238, 20);
            this.textBoxNhancong.TabIndex = 6;
            // 
            // textBoxDiennuoc
            // 
            this.textBoxDiennuoc.Location = new System.Drawing.Point(143, 143);
            this.textBoxDiennuoc.Name = "textBoxDiennuoc";
            this.textBoxDiennuoc.Size = new System.Drawing.Size(238, 20);
            this.textBoxDiennuoc.TabIndex = 7;
            // 
            // textBoxNha
            // 
            this.textBoxNha.Location = new System.Drawing.Point(143, 201);
            this.textBoxNha.Name = "textBoxNha";
            this.textBoxNha.Size = new System.Drawing.Size(238, 20);
            this.textBoxNha.TabIndex = 8;
            // 
            // textBoxHoahong
            // 
            this.textBoxHoahong.Location = new System.Drawing.Point(143, 259);
            this.textBoxHoahong.Name = "textBoxHoahong";
            this.textBoxHoahong.Size = new System.Drawing.Size(238, 20);
            this.textBoxHoahong.TabIndex = 9;
            // 
            // textBoxKhac
            // 
            this.textBoxKhac.Location = new System.Drawing.Point(143, 317);
            this.textBoxKhac.Name = "textBoxKhac";
            this.textBoxKhac.Size = new System.Drawing.Size(238, 20);
            this.textBoxKhac.TabIndex = 10;
            // 
            // buttonQuaylai
            // 
            this.buttonQuaylai.Location = new System.Drawing.Point(-7, -1);
            this.buttonQuaylai.Name = "buttonQuaylai";
            this.buttonQuaylai.Size = new System.Drawing.Size(75, 23);
            this.buttonQuaylai.TabIndex = 11;
            this.buttonQuaylai.Text = "Quay lại";
            this.buttonQuaylai.UseVisualStyleBackColor = true;
            this.buttonQuaylai.Click += new System.EventHandler(this.buttonQuaylai_Click);
            // 
            // buttonThietlap
            // 
            this.buttonThietlap.Location = new System.Drawing.Point(344, 375);
            this.buttonThietlap.Name = "buttonThietlap";
            this.buttonThietlap.Size = new System.Drawing.Size(75, 23);
            this.buttonThietlap.TabIndex = 12;
            this.buttonThietlap.Text = "Thiết lập";
            this.buttonThietlap.UseVisualStyleBackColor = true;
            this.buttonThietlap.Click += new System.EventHandler(this.buttonThietlap_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trangChủToolStripMenuItem,
            this.quảnLýToolStripMenuItem,
            this.thiếtLậpToolStripMenuItem,
            this.thốngKêToolStripMenuItem,
            this.thayĐổiTàiKhoảnToolStripMenuItem,
            this.đăngXuấtToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(431, 24);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // trangChủToolStripMenuItem
            // 
            this.trangChủToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.trangChủToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.trangChủToolStripMenuItem.Name = "trangChủToolStripMenuItem";
            this.trangChủToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.trangChủToolStripMenuItem.Text = "Trang chủ";
            this.trangChủToolStripMenuItem.Click += new System.EventHandler(this.trangChủToolStripMenuItem_Click);
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýThànhViênToolStripMenuItem,
            this.quảnLýHàngToolStripMenuItem,
            this.quảnLýThángLươngToolStripMenuItem,
            this.quảnLýNhậpHàngToolStripMenuItem});
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.quảnLýToolStripMenuItem.Text = "Quản lý";
            this.quảnLýToolStripMenuItem.Click += new System.EventHandler(this.quảnLýToolStripMenuItem_Click);
            // 
            // quảnLýThànhViênToolStripMenuItem
            // 
            this.quảnLýThànhViênToolStripMenuItem.Name = "quảnLýThànhViênToolStripMenuItem";
            this.quảnLýThànhViênToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.quảnLýThànhViênToolStripMenuItem.Text = "Quản lý thành viên";
            this.quảnLýThànhViênToolStripMenuItem.Click += new System.EventHandler(this.quảnLýThànhViênToolStripMenuItem_Click);
            // 
            // quảnLýHàngToolStripMenuItem
            // 
            this.quảnLýHàngToolStripMenuItem.Name = "quảnLýHàngToolStripMenuItem";
            this.quảnLýHàngToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.quảnLýHàngToolStripMenuItem.Text = "Quản lý hàng";
            this.quảnLýHàngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýHàngToolStripMenuItem_Click);
            // 
            // quảnLýThángLươngToolStripMenuItem
            // 
            this.quảnLýThángLươngToolStripMenuItem.Name = "quảnLýThángLươngToolStripMenuItem";
            this.quảnLýThángLươngToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.quảnLýThángLươngToolStripMenuItem.Text = "Quản lý tháng lương";
            this.quảnLýThángLươngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýThángLươngToolStripMenuItem_Click);
            // 
            // quảnLýNhậpHàngToolStripMenuItem
            // 
            this.quảnLýNhậpHàngToolStripMenuItem.Name = "quảnLýNhậpHàngToolStripMenuItem";
            this.quảnLýNhậpHàngToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.quảnLýNhậpHàngToolStripMenuItem.Text = "Quản lý nhập hàng";
            this.quảnLýNhậpHàngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýNhậpHàngToolStripMenuItem_Click);
            // 
            // thiếtLậpToolStripMenuItem
            // 
            this.thiếtLậpToolStripMenuItem.BackColor = System.Drawing.Color.Red;
            this.thiếtLậpToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.thiếtLậpToolStripMenuItem.Name = "thiếtLậpToolStripMenuItem";
            this.thiếtLậpToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.thiếtLậpToolStripMenuItem.Text = "Thiết lập";
            this.thiếtLậpToolStripMenuItem.Click += new System.EventHandler(this.thiếtLậpToolStripMenuItem_Click);
            // 
            // thốngKêToolStripMenuItem
            // 
            this.thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            this.thốngKêToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.thốngKêToolStripMenuItem.Text = "Thống kê";
            this.thốngKêToolStripMenuItem.Click += new System.EventHandler(this.thốngKêToolStripMenuItem_Click);
            // 
            // thayĐổiTàiKhoảnToolStripMenuItem
            // 
            this.thayĐổiTàiKhoảnToolStripMenuItem.Name = "thayĐổiTàiKhoảnToolStripMenuItem";
            this.thayĐổiTàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(116, 20);
            this.thayĐổiTàiKhoảnToolStripMenuItem.Text = "Thay đổi tài khoản";
            this.thayĐổiTàiKhoảnToolStripMenuItem.Click += new System.EventHandler(this.thayĐổiTàiKhoảnToolStripMenuItem_Click);
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            // 
            // Thietlap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 410);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.buttonThietlap);
            this.Controls.Add(this.buttonQuaylai);
            this.Controls.Add(this.textBoxKhac);
            this.Controls.Add(this.textBoxHoahong);
            this.Controls.Add(this.textBoxNha);
            this.Controls.Add(this.textBoxDiennuoc);
            this.Controls.Add(this.textBoxNhancong);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Thietlap";
            this.Text = "Thietlap";
            this.Load += new System.EventHandler(this.Thietlap_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxNhancong;
        private System.Windows.Forms.TextBox textBoxDiennuoc;
        private System.Windows.Forms.TextBox textBoxNha;
        private System.Windows.Forms.TextBox textBoxHoahong;
        private System.Windows.Forms.TextBox textBoxKhac;
        private System.Windows.Forms.Button buttonQuaylai;
        private System.Windows.Forms.Button buttonThietlap;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem trangChủToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýThànhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýThángLươngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýNhậpHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thiếtLậpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thayĐổiTàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
    }
}