﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTLWindow
{
    public partial class QLHang : Form
    {
        BLLHang hang = new BLLHang();
        private int row;
        public QLHang()
        {
            InitializeComponent();
        }

        private void buttonQuaylai_Click(object sender, EventArgs e)
        {
            Menu a = new Menu();
            a.Show();
            this.Close();
        }

        private void buttonThem_Click(object sender, EventArgs e)
        {
            try
            {
                hang.insert(textBoxMahang.Text.ToString(), textBoxTen.Text.Trim(), textBoxNsx.Text.Trim(), dateTimePickerHsd.Value, Int32.Parse(textBoxGiaban.Text.Trim()));
                this.load_data();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonSua_Click(object sender, EventArgs e)
        {
            try
            {
                hang.update(textBoxMahang.Text.ToString(), textBoxTen.Text.Trim(), textBoxNsx.Text.Trim(), dateTimePickerHsd.Value, Int32.Parse(textBoxGiaban.Text.Trim()));
                this.load_data();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonXoa_Click(object sender, EventArgs e)
        {
            try
            {
                hang.delete(textBoxMahang.Text.Trim());
                this.load_data();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void load_data()
        {
            DataTable a = new DataTable();
            a = hang.selectHang();
            dataGridView.DataSource = a;
        }

        private void QLHang_Load(object sender, EventArgs e)
        {
            this.load_data();
        }

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.row = e.RowIndex;
            try
            {
                textBoxMahang.Text = dataGridView.Rows[row].Cells[0].Value.ToString();
                textBoxTen.Text = dataGridView.Rows[row].Cells[1].Value.ToString();
                textBoxNsx.Text = dataGridView.Rows[row].Cells[2].Value.ToString();
                textBoxGiaban.Text = dataGridView.Rows[row].Cells[4].Value.ToString();
                dateTimePickerHsd.Value = Convert.ToDateTime(dataGridView.Rows[row].Cells[3].Value.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void trangChủToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Menutrip a = new Menutrip();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThànhViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLnhanvien a = new QLnhanvien();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLHang a = new QLHang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThángLươngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLLuongThang a = new QLLuongThang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýNhậpHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLNhaphang a = new QLNhaphang();
            this.Hide();
            a.ShowDialog();
        }

        private void thiếtLậpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thietlap a = new Thietlap();
            this.Hide();
            a.ShowDialog();
        }

        private void thốngKêToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thongke a = new Thongke();
            this.Hide();
            a.ShowDialog();
        }

        private void thayĐổiTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thaydoimk a = new Thaydoimk();
            this.Hide();
            a.ShowDialog();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            this.Hide();
            a.ShowDialog();
        }
    }
}
