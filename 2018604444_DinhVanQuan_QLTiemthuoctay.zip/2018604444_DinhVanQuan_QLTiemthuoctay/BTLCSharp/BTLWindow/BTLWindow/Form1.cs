﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace BTLWindow
{
    public partial class Form1 : Form
    {
        BLLTaikhoan a = new BLLTaikhoan();
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        public Boolean checkQuanLy(String ten,String matkhau)
        {
            DataTable data = a.takeQuanly();
            foreach(DataRow i in data.Rows)
            {
                if (i["ten"].ToString().Equals(ten) && i["matkhau"].ToString().Equals(matkhau))
                    return true;
            }
            return false;
        }

        public Boolean checkNhanVien(String ten, String matkhau)
        {
            DataTable data = a.takeNhanvien();
            foreach (DataRow i in data.Rows)
            {
                if (i["ten"].ToString().Equals(ten) && i["matkhau"].ToString().Equals(matkhau))
                    return true;
            }
            return false;
        }

        public void close()
        {
            Menu a = new Menu();
            this.Hide();
            a.ShowDialog();
        }

        private void buttonDangnhap_Click(object sender, EventArgs e)
        {
            String ten = textBoxTen.Text.Trim();
            String matkhau = textBoxMatkhau.Text.Trim();
            if (checkQuanLy(ten, matkhau) == true)
            {
                Menutrip a = new Menutrip();
                this.Hide();
                a.ShowDialog();
            }
            else if(checkNhanVien(ten, matkhau) == true)
            {
                User1 a = new User1(ten);
                this.Hide();
                a.ShowDialog();
            }
            else
                MessageBox.Show("Không đúng tên tài khoản hoặc mật khẩu!");
            
        }

        private void buttonThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
