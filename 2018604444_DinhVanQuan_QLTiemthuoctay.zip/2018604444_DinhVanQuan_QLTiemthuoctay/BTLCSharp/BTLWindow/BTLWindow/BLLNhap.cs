﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace BTLWindow
{
    class BLLNhap
    {
        DAL data = new DAL();
        
        public DataTable selectNhap()
        {
            String sql = "select * from nhap";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }

        public void delete(DateTime date, String mahang)
        {
            String sql = "delete nhap where date='" + date.ToString("yyyy-MM-dd") + "' and mahang='" + mahang + "'";
            data.ExecNonQuery(sql);
        }

        public void insert(DateTime date, String mahang, int soluong, int gianhap)
        {
            String sql = "insert into nhap values('" + date.ToString("yyyy-MM-dd") + "','" + mahang + "'," + soluong + "," + gianhap + ") ";
            data.ExecNonQuery(sql);
        }

        public void update(DateTime date, String mahang, int soluong, int gianhap)
        {
            String sql = "update nhap set soluong= " + soluong + ",gianhap=" + gianhap + " where date='" + date.ToString("yyyy-MM-dd") + "' and mahang='" + mahang + "'";
            data.ExecNonQuery(sql);
        }

        public DataTable tongnhap(DateTime date)
        {
            String sql = "select dbo.tong_nhap_hang('" + date.ToString("yyyy-MM-dd") + "')";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }
    }
}
