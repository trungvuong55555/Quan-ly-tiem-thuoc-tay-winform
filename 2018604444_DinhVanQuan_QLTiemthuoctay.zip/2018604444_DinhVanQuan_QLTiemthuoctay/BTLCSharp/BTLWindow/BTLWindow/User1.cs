﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections.Generic;

namespace BTLWindow
{
    public partial class User1 : Form
    {
        private String ten;
        private String mahoadon;
        private DateTime ngay;
        private String mahang;
        private int soluong;
        private int vitri1;
        private int vitri2;

        BLLHang hang = new BLLHang();
        BLLChitiethoadon cthd = new BLLChitiethoadon();
        public User1()
        {
            InitializeComponent();
        }

        public User1(String ten)
        {
            this.ten = ten;
            InitializeComponent();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            this.Hide();
            a.ShowDialog();

        }

        private void thayĐổiMậtKhẩuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ThaydoimkNhanvien a = new ThaydoimkNhanvien(this.ten);
            this.Hide();
            a.ShowDialog();

        }

        private void User1_Load(object sender, EventArgs e)
        {
            this.load_formhang(sender, e);
        }

        public void load_formcthd(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = cthd.showmathangmua(this.mahoadon);
            dataGridViewHoadon.DataSource = dt;
        }

        public void load_formhang(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = hang.showTenhang();
            dataGridViewHang.DataSource = dt;
        }


        private void dataGridViewHang_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            vitri1 = e.RowIndex;


            if (vitri1 >= 0)
            {

                this.mahang = dataGridViewHang.Rows[vitri1].Cells[0].Value.ToString();
                String value1 = Interaction.InputBox("Nhập số lượng bán", "Nhập số lượng", "0", 500, 300);
                int soluong;
                try
                {
                    soluong = Int32.Parse(value1);
                    cthd.insert(this.mahoadon, this.mahang, soluong);
                    this.load_formcthd(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }







            }


        }

        private void dataGridViewHoadon_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

        private void buttonLuu_Click(object sender, EventArgs e)
        {
            if (textBoxMahoadon.Text.Trim() != "")
            {
                textBoxMahoadon.Enabled = false;
                dateTimePickerNgaynhap.Enabled = false;
                this.mahoadon = textBoxMahoadon.Text.Trim();
                this.ngay = dateTimePickerNgaynhap.Value;
                BLLQLHoadon a = new BLLQLHoadon();
                a.insert(this.mahoadon, this.ngay, this.ten);
                buttonLuu.Enabled = false;
            }
            else
                MessageBox.Show("Mã hóa đơn không được để trống!");
        }

        private void buttonXoa_Click(object sender, EventArgs e)
        {
            String mahang = dataGridViewHoadon.Rows[vitri2].Cells[1].ToString();
            cthd.delete(this.mahoadon, mahang);
            this.load_formcthd(sender, e);
        }

        private void buttonSua_Click(object sender, EventArgs e)
        {
            String mahang = dataGridViewHoadon.Rows[vitri2].Cells[1].ToString();
            String value1 = Interaction.InputBox("Nhập số lượng muốn thay đổi: ", "Nhập số lượng", "0", 500, 300);
            int soluong;
            try
            {
                soluong = Int32.Parse(value1);
                cthd.update(this.mahoadon, mahang, soluong);
                this.load_formcthd(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    

        private void buttonLammoi_Click(object sender, EventArgs e)
        {
            textBoxMahoadon.Enabled = true;
            dateTimePickerNgaynhap.Enabled = true;
            textBoxMahoadon.Text = "";
            textBoxTongtien.Text = "";
            this.mahoadon = null;
            //this.ngay = null;
            load_formhang(sender, e);
            dateTimePickerNgaynhap.Value = DateTime.Now;
            dataGridViewHoadon.DataSource = null;
            buttonLuu.Enabled = true;
            this.mahang = null;
        }

        private void buttonTimkiemhang_Click(object sender, EventArgs e)
        {
            DataTable data = new DataTable();
            data = hang.findTenhang(textBoxTimkiemhang.Text);
            dataGridViewHang.DataSource = data;
        }

        private void buttonTongtien_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable data = cthd.tongtien(this.mahoadon);
                foreach (DataRow row in data.Rows)
                {
                    textBoxTongtien.Text = row[0].ToString();
                    
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridViewHoadon_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            vitri2 = e.RowIndex;
        }
    }
}
