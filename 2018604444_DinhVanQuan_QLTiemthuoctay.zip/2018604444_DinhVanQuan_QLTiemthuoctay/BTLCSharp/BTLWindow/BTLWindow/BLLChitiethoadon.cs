﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace BTLWindow
{
    class BLLChitiethoadon
    {
        DAL data = new DAL();

        public DataTable selectChitiethang(String mahoadon)
        {
            String sql = "select Hang.mahang,tenhang,nsx,hsd,giaban,soluong from hang inner join chitiethoadon on hang.mahang=chitiethoadon.mahang where mahoadon='"+mahoadon+"'";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }

        public void insert(String mahoadon, String mahang,int soluong)
        {
            try
            {
                String sql = "insert into chitiethoadon values('" + mahoadon + "','" + mahang + "'," + soluong + ")";
                data.ExecNonQuery(sql);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void delete(String mahoadon, String mahang)
        {
            try
            {
                String sql = "delete chitiethoadon where mahoadon='" + mahoadon + "' and mahang='" + mahang + "'";
                data.ExecNonQuery(sql);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void update(String mahoadon, String mahang, int soluong)
        {
            try
            {
                String sql = "update chitiethoadon set soluong=" + soluong + " where mahoadon='" + mahoadon + "' and mahang='" + mahang + "'";
                data.ExecNonQuery(sql);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public DataTable selectTongtien(String mahoadon)
        {
            String sql = "select Hang.mahang,soluong,giaban from hang inner join chitiethoadon on hang.mahang=chitiethoadon.mahang where mahoadon='"+mahoadon+"'";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }

        public DataTable showmathangmua(String mahoadon)
        {
            String sql = "select * from dbo.show_mat_hang_mua1('" + mahoadon + "')";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }

        public DataTable tongtien(String mahoadon)
        {
            String sql = "select dbo.tongtien_muahang('" + mahoadon + "')";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }

    }
}
