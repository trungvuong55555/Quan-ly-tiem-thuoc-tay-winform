﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTLWindow
{
    public partial class Thaydoimk : Form
    {
        BLLTaikhoan tk = new BLLTaikhoan();
        public Thaydoimk()
        {
            InitializeComponent();
        }

        private void buttonQuaylai_Click(object sender, EventArgs e)
        {
            Menu a = new Menu();
            a.Show();
            this.Close();
        }

        public Boolean checkQuanLy(String ten, String matkhau)
        {
            DataTable data = tk.takeQuanly();
            foreach (DataRow i in data.Rows)
            {
                if (i["ten"].ToString().Equals(ten) && i["matkhau"].ToString().Equals(matkhau))
                    return true;
            }
            return false;
        }
        private void buttonThaydoi_Click(object sender, EventArgs e)
        {
            if (this.checkQuanLy(textBoxTencu.Text.Trim(), textBoxMKcu.Text))
            {
                if (textBoxMatkhaumoi.Text.Equals(textBoxNhaplai.Text))
                {
                    tk.update_quanly(textBoxTencu.Text.Trim(), textBoxNhaplai.Text, textBoxTen.Text.Trim());
                    MessageBox.Show("Bạn đã thay đổi mật khẩu thành công!");
                }
                else
                    MessageBox.Show("Bạn đã nhập xác nhận mật khẩu mới sai!");
            }
            else
                MessageBox.Show("Bạn đã nhập sai tài khoản ban đầu!");
        }

        private void quảnLýToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void trangChủToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Menutrip a = new Menutrip();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThànhViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLnhanvien a = new QLnhanvien();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLHang a = new QLHang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThángLươngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLLuongThang a = new QLLuongThang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýNhậpHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLNhaphang a = new QLNhaphang();
            this.Hide();
            a.ShowDialog();
        }

        private void thiếtLậpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thietlap a = new Thietlap();
            this.Hide();
            a.ShowDialog();
        }

        private void thốngKêToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thongke a = new Thongke();
            this.Hide();
            a.ShowDialog();
        }

        private void thayĐổiTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thaydoimk a = new Thaydoimk();
            this.Hide();
            a.ShowDialog();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            this.Hide();
            a.ShowDialog();
        }
    }
}
