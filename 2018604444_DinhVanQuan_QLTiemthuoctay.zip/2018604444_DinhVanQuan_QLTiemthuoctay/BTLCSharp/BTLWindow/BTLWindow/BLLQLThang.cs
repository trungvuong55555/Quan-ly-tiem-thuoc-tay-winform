﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace BTLWindow
{
    class BLLQLThang
    {
        DAL data = new DAL();

        public DataTable selectQLThang()
        {
            String sql = "select * from qlthang";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }

        public void insert(DateTime date, String matv, int songaylam)
        {
            try
            {
                String ngay = date.ToString("yyyy-MM-dd");
                String sql = "insert into qlthang values((select eomonth('" + ngay + "')),'" + matv + "'," + songaylam + ",'d1')";
                data.ExecNonQuery(sql);
            }catch(SqlException ex)
            {
                String ngay = date.ToString("yyyy-MM-dd");
                MessageBox.Show(ex.Message);
                MessageBox.Show(ngay);
            }
        }

        public void update(DateTime date, String matv, int songaylam)
        {
            try
            {
                String ngay = date.ToString("yyyy-MM-dd");
                String sql = "upate qlthang set songaylam=" + songaylam + " where date= (select EOMONTH('" + ngay + "')) and matv='" + matv + "'";
                data.ExecNonQuery(sql);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void delete(DateTime date, String matv)
        {
            try
            {
                String sql = "delete qlthang where date= (select EOMONTH('" + date.ToString("yyyy-MM-dd") + "')) and matv='" + matv + "' ";
                data.ExecNonQuery(sql);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public DataTable date_load(DateTime date)
        {
            try
            {
                String sql = "select date,matv,songaylam from qlthang where date='" + date.ToString("yyyyy-MM-dd") + "'";
                DataTable a = new DataTable();
                a = data.GetTable(sql);
                return a;
            }catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        public DataTable show_luong_thang(DateTime date)
        {
            try
            {
                String sql = "select * from bangtinh_tong_tien_cong('" + date.ToString("yyyy-MM-dd") + "')";
                DataTable a = new DataTable();
                a = data.GetTable(sql);
                return a;

            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        public DataTable tong_tra_cong(DateTime date)
        {
            String sql = "select dbo.tong_tien_cong('" + date.ToString("yyyy-MM-dd") + "')";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }
       
    }
}
