﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace BTLWindow
{
    class BLLQLLuongcoban
    {
        DAL a = new DAL();
        public void update(String maluong, int tien)
        {
            String sql = "update Luongcoban set tien= " + tien + " where maluong= '" + maluong + "'";
            a.ExecNonQuery(sql);
        }

        public DataTable getData()
        {
            String sql = "select * from Luongcoban";
            DataTable dt = new DataTable();
            dt = a.GetTable(sql);
            return dt;
        }

        public DataTable find(String ma)
        {
            String sql = "select * from Luongcoban where where maluong= '" + ma + "'";
            DataTable dt = new DataTable();
            dt = a.GetTable(sql);
            return dt;
        }

        public DataTable tongthu(DateTime date)
        {
            String sql = "select dbo.tong_ban('" + date.ToString("yyyy-MM-dd") + "')";
            DataTable dt = new DataTable();
            dt = a.GetTable(sql);
            return dt;
        }

        public DataTable tongchi(DateTime date)
        {
            String sql = "select dbo.tong_chi('" + date.ToString("yyyy-MM-dd") + "')";
            DataTable dt = new DataTable();
            dt = a.GetTable(sql);
            return dt;
        }

        public DataTable tong(DateTime date)
        {
            String sql = "select dbo.thongke('" + date.ToString("yyyy-MM-dd") + "')";
            DataTable dt = new DataTable();
            dt = a.GetTable(sql);
            return dt;
        }
    }
}
