﻿
namespace BTLWindow
{
    partial class QLNhaphang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewQLNhap = new System.Windows.Forms.DataGridView();
            this.ColumnDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMahang1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSoluongnhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnGianhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewHang = new System.Windows.Forms.DataGridView();
            this.ColumnMahang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTenhang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSoluong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePickerNgaynhap = new System.Windows.Forms.DateTimePicker();
            this.textBoxMahang = new System.Windows.Forms.TextBox();
            this.textBoxSoluong = new System.Windows.Forms.TextBox();
            this.textBoxGianhap = new System.Windows.Forms.TextBox();
            this.buttonQuaylai = new System.Windows.Forms.Button();
            this.buttonThem = new System.Windows.Forms.Button();
            this.buttonSua = new System.Windows.Forms.Button();
            this.buttonXoa = new System.Windows.Forms.Button();
            this.textBoxTimkiem = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.trangChủToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýThànhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýThángLươngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýNhậpHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thiếtLậpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thayĐổiTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewQLNhap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHang)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewQLNhap
            // 
            this.dataGridViewQLNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewQLNhap.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnDate,
            this.ColumnMahang1,
            this.ColumnSoluongnhap,
            this.ColumnGianhap});
            this.dataGridViewQLNhap.Location = new System.Drawing.Point(0, 300);
            this.dataGridViewQLNhap.Name = "dataGridViewQLNhap";
            this.dataGridViewQLNhap.Size = new System.Drawing.Size(444, 150);
            this.dataGridViewQLNhap.TabIndex = 0;
            this.dataGridViewQLNhap.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewQLNhap_CellContentClick);
            // 
            // ColumnDate
            // 
            this.ColumnDate.DataPropertyName = "date";
            this.ColumnDate.HeaderText = "Ngày nhập";
            this.ColumnDate.Name = "ColumnDate";
            // 
            // ColumnMahang1
            // 
            this.ColumnMahang1.DataPropertyName = "mahang";
            this.ColumnMahang1.HeaderText = "Mã hàng";
            this.ColumnMahang1.Name = "ColumnMahang1";
            // 
            // ColumnSoluongnhap
            // 
            this.ColumnSoluongnhap.DataPropertyName = "soluong";
            this.ColumnSoluongnhap.HeaderText = "Số lượng nhập";
            this.ColumnSoluongnhap.Name = "ColumnSoluongnhap";
            // 
            // ColumnGianhap
            // 
            this.ColumnGianhap.DataPropertyName = "gianhap";
            this.ColumnGianhap.HeaderText = "Giá nhập";
            this.ColumnGianhap.Name = "ColumnGianhap";
            // 
            // dataGridViewHang
            // 
            this.dataGridViewHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnMahang,
            this.ColumnTenhang,
            this.ColumnSoluong});
            this.dataGridViewHang.Location = new System.Drawing.Point(450, 56);
            this.dataGridViewHang.Name = "dataGridViewHang";
            this.dataGridViewHang.Size = new System.Drawing.Size(346, 339);
            this.dataGridViewHang.TabIndex = 1;
            this.dataGridViewHang.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewHang_CellClick);
            // 
            // ColumnMahang
            // 
            this.ColumnMahang.DataPropertyName = "mahang";
            this.ColumnMahang.HeaderText = "Mã hàng";
            this.ColumnMahang.Name = "ColumnMahang";
            // 
            // ColumnTenhang
            // 
            this.ColumnTenhang.DataPropertyName = "tenhang";
            this.ColumnTenhang.HeaderText = "Tên hàng";
            this.ColumnTenhang.Name = "ColumnTenhang";
            // 
            // ColumnSoluong
            // 
            this.ColumnSoluong.DataPropertyName = "soluongco";
            this.ColumnSoluong.HeaderText = "Số lượng có";
            this.ColumnSoluong.Name = "ColumnSoluong";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(272, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(252, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "QUẢN LÝ NHẬP HÀNG";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Ngày nhập:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 122);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Mã hàng:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Số lượng:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 254);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Giá nhập:";
            // 
            // dateTimePickerNgaynhap
            // 
            this.dateTimePickerNgaynhap.Location = new System.Drawing.Point(104, 56);
            this.dateTimePickerNgaynhap.Name = "dateTimePickerNgaynhap";
            this.dateTimePickerNgaynhap.Size = new System.Drawing.Size(221, 20);
            this.dateTimePickerNgaynhap.TabIndex = 7;
            // 
            // textBoxMahang
            // 
            this.textBoxMahang.Location = new System.Drawing.Point(104, 115);
            this.textBoxMahang.Name = "textBoxMahang";
            this.textBoxMahang.Size = new System.Drawing.Size(221, 20);
            this.textBoxMahang.TabIndex = 8;
            // 
            // textBoxSoluong
            // 
            this.textBoxSoluong.Location = new System.Drawing.Point(104, 183);
            this.textBoxSoluong.Name = "textBoxSoluong";
            this.textBoxSoluong.Size = new System.Drawing.Size(221, 20);
            this.textBoxSoluong.TabIndex = 9;
            // 
            // textBoxGianhap
            // 
            this.textBoxGianhap.Location = new System.Drawing.Point(104, 251);
            this.textBoxGianhap.Name = "textBoxGianhap";
            this.textBoxGianhap.Size = new System.Drawing.Size(221, 20);
            this.textBoxGianhap.TabIndex = 10;
            // 
            // buttonQuaylai
            // 
            this.buttonQuaylai.Location = new System.Drawing.Point(0, 0);
            this.buttonQuaylai.Name = "buttonQuaylai";
            this.buttonQuaylai.Size = new System.Drawing.Size(75, 23);
            this.buttonQuaylai.TabIndex = 11;
            this.buttonQuaylai.Text = "Quay lại";
            this.buttonQuaylai.UseVisualStyleBackColor = true;
            this.buttonQuaylai.Click += new System.EventHandler(this.buttonQuaylai_Click);
            // 
            // buttonThem
            // 
            this.buttonThem.Location = new System.Drawing.Point(343, 70);
            this.buttonThem.Name = "buttonThem";
            this.buttonThem.Size = new System.Drawing.Size(75, 23);
            this.buttonThem.TabIndex = 12;
            this.buttonThem.Text = "Thêm";
            this.buttonThem.UseVisualStyleBackColor = true;
            this.buttonThem.Click += new System.EventHandler(this.buttonThem_Click);
            // 
            // buttonSua
            // 
            this.buttonSua.Location = new System.Drawing.Point(343, 151);
            this.buttonSua.Name = "buttonSua";
            this.buttonSua.Size = new System.Drawing.Size(75, 23);
            this.buttonSua.TabIndex = 13;
            this.buttonSua.Text = "Sửa";
            this.buttonSua.UseVisualStyleBackColor = true;
            this.buttonSua.Click += new System.EventHandler(this.buttonSua_Click);
            // 
            // buttonXoa
            // 
            this.buttonXoa.Location = new System.Drawing.Point(343, 232);
            this.buttonXoa.Name = "buttonXoa";
            this.buttonXoa.Size = new System.Drawing.Size(75, 23);
            this.buttonXoa.TabIndex = 14;
            this.buttonXoa.Text = "Xóa";
            this.buttonXoa.UseVisualStyleBackColor = true;
            this.buttonXoa.Click += new System.EventHandler(this.buttonXoa_Click);
            // 
            // textBoxTimkiem
            // 
            this.textBoxTimkiem.Location = new System.Drawing.Point(559, 401);
            this.textBoxTimkiem.Name = "textBoxTimkiem";
            this.textBoxTimkiem.Size = new System.Drawing.Size(155, 20);
            this.textBoxTimkiem.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(606, 427);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "Tìm kiếm";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trangChủToolStripMenuItem,
            this.quảnLýToolStripMenuItem,
            this.thiếtLậpToolStripMenuItem,
            this.thốngKêToolStripMenuItem,
            this.thayĐổiTàiKhoảnToolStripMenuItem,
            this.đăngXuấtToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // trangChủToolStripMenuItem
            // 
            this.trangChủToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.trangChủToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.trangChủToolStripMenuItem.Name = "trangChủToolStripMenuItem";
            this.trangChủToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.trangChủToolStripMenuItem.Text = "Trang chủ";
            this.trangChủToolStripMenuItem.Click += new System.EventHandler(this.trangChủToolStripMenuItem_Click);
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.BackColor = System.Drawing.Color.Red;
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýThànhViênToolStripMenuItem,
            this.quảnLýHàngToolStripMenuItem,
            this.quảnLýThángLươngToolStripMenuItem,
            this.quảnLýNhậpHàngToolStripMenuItem});
            this.quảnLýToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.quảnLýToolStripMenuItem.Text = "Quản lý";
            // 
            // quảnLýThànhViênToolStripMenuItem
            // 
            this.quảnLýThànhViênToolStripMenuItem.Name = "quảnLýThànhViênToolStripMenuItem";
            this.quảnLýThànhViênToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.quảnLýThànhViênToolStripMenuItem.Text = "Quản lý thành viên";
            this.quảnLýThànhViênToolStripMenuItem.Click += new System.EventHandler(this.quảnLýThànhViênToolStripMenuItem_Click);
            // 
            // quảnLýHàngToolStripMenuItem
            // 
            this.quảnLýHàngToolStripMenuItem.Name = "quảnLýHàngToolStripMenuItem";
            this.quảnLýHàngToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.quảnLýHàngToolStripMenuItem.Text = "Quản lý hàng";
            this.quảnLýHàngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýHàngToolStripMenuItem_Click);
            // 
            // quảnLýThángLươngToolStripMenuItem
            // 
            this.quảnLýThángLươngToolStripMenuItem.Name = "quảnLýThángLươngToolStripMenuItem";
            this.quảnLýThángLươngToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.quảnLýThángLươngToolStripMenuItem.Text = "Quản lý tháng lương";
            this.quảnLýThángLươngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýThángLươngToolStripMenuItem_Click);
            // 
            // quảnLýNhậpHàngToolStripMenuItem
            // 
            this.quảnLýNhậpHàngToolStripMenuItem.Name = "quảnLýNhậpHàngToolStripMenuItem";
            this.quảnLýNhậpHàngToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.quảnLýNhậpHàngToolStripMenuItem.Text = "Quản lý nhập hàng";
            this.quảnLýNhậpHàngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýNhậpHàngToolStripMenuItem_Click);
            // 
            // thiếtLậpToolStripMenuItem
            // 
            this.thiếtLậpToolStripMenuItem.Name = "thiếtLậpToolStripMenuItem";
            this.thiếtLậpToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.thiếtLậpToolStripMenuItem.Text = "Thiết lập";
            this.thiếtLậpToolStripMenuItem.Click += new System.EventHandler(this.thiếtLậpToolStripMenuItem_Click);
            // 
            // thốngKêToolStripMenuItem
            // 
            this.thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            this.thốngKêToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.thốngKêToolStripMenuItem.Text = "Thống kê";
            this.thốngKêToolStripMenuItem.Click += new System.EventHandler(this.thốngKêToolStripMenuItem_Click);
            // 
            // thayĐổiTàiKhoảnToolStripMenuItem
            // 
            this.thayĐổiTàiKhoảnToolStripMenuItem.Name = "thayĐổiTàiKhoảnToolStripMenuItem";
            this.thayĐổiTàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(116, 20);
            this.thayĐổiTàiKhoảnToolStripMenuItem.Text = "Thay đổi tài khoản";
            this.thayĐổiTàiKhoảnToolStripMenuItem.Click += new System.EventHandler(this.thayĐổiTàiKhoảnToolStripMenuItem_Click);
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // QLNhaphang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBoxTimkiem);
            this.Controls.Add(this.buttonXoa);
            this.Controls.Add(this.buttonSua);
            this.Controls.Add(this.buttonThem);
            this.Controls.Add(this.buttonQuaylai);
            this.Controls.Add(this.textBoxGianhap);
            this.Controls.Add(this.textBoxSoluong);
            this.Controls.Add(this.textBoxMahang);
            this.Controls.Add(this.dateTimePickerNgaynhap);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewHang);
            this.Controls.Add(this.dataGridViewQLNhap);
            this.Name = "QLNhaphang";
            this.Text = "QLNhaphang";
            this.Load += new System.EventHandler(this.QLNhaphang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewQLNhap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHang)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewQLNhap;
        private System.Windows.Forms.DataGridView dataGridViewHang;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgaynhap;
        private System.Windows.Forms.TextBox textBoxMahang;
        private System.Windows.Forms.TextBox textBoxSoluong;
        private System.Windows.Forms.TextBox textBoxGianhap;
        private System.Windows.Forms.Button buttonQuaylai;
        private System.Windows.Forms.Button buttonThem;
        private System.Windows.Forms.Button buttonSua;
        private System.Windows.Forms.Button buttonXoa;
        private System.Windows.Forms.TextBox textBoxTimkiem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMahang;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTenhang;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSoluong;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMahang1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSoluongnhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnGianhap;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem trangChủToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýThànhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýThángLươngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýNhậpHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thiếtLậpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thayĐổiTàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
    }
}