﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTLWindow
{
    public partial class Thietlap : Form
    {
        BLLQLLuongcoban lcb = new BLLQLLuongcoban();
        public Thietlap()
        {
            InitializeComponent();
        }

        private void buttonQuaylai_Click(object sender, EventArgs e)
        {
            Menu a = new Menu();
            a.Show();
            this.Close();
        }

        private void buttonThietlap_Click(object sender, EventArgs e)
        {
            try
            {
                lcb.update("d1", Int32.Parse(textBoxNhancong.Text.Trim()));
                lcb.update("d3", Int32.Parse(textBoxDiennuoc.Text.Trim()));
                lcb.update("d2", Int32.Parse(textBoxNha.Text.Trim()));
                lcb.update("d5", Int32.Parse(textBoxHoahong.Text.Trim()));
                lcb.update("d4", Int32.Parse(textBoxKhac.Text.Trim()));
                MessageBox.Show("Thiết lập thành công!");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Thietlap_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable data = new DataTable();
                data = lcb.getData();
                List<String> list = new List<String>();
                foreach (DataRow row in data.Rows)
                {
                    String a = row[2].ToString();
                    list.Add(a);
                }

                textBoxNhancong.Text = list[0];
                textBoxNha.Text = list[1];
                textBoxDiennuoc.Text = list[2];
                textBoxKhac.Text = list[3];
                textBoxHoahong.Text = list[4];
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void quảnLýToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void trangChủToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Menutrip a = new Menutrip();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThànhViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLnhanvien a = new QLnhanvien();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLHang a = new QLHang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThángLươngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLLuongThang a = new QLLuongThang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýNhậpHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLNhaphang a = new QLNhaphang();
            this.Hide();
            a.ShowDialog();
        }

        private void thiếtLậpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thietlap a = new Thietlap();
            this.Hide();
            a.ShowDialog();
        }

        private void thốngKêToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thongke a = new Thongke();
            this.Hide();
            a.ShowDialog();
        }

        private void thayĐổiTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thaydoimk a = new Thaydoimk();
            this.Hide();
            a.ShowDialog();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            this.Hide();
            a.ShowDialog();
        }
    }
}
