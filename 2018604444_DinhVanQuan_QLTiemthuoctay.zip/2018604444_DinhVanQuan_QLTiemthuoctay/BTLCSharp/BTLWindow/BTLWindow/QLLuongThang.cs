﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections.Generic;

namespace BTLWindow
{
    public partial class QLLuongThang : Form
    {
        BLLThanhvien thanhvien = new BLLThanhvien();
        BLLQLThang thang = new BLLQLThang();
        private int row1;
        private int row2;

        private DateTime ngay;
        public QLLuongThang()
        {
            InitializeComponent();
        }

        private void buttonQuaylai_Click(object sender, EventArgs e)
        {
            Menu a = new Menu();
            this.Hide();
            a.ShowDialog();
        }

        private void buttonTimkiem_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable a = new DataTable();
                a = thanhvien.findHoten(textBoxTimkiem.Text.Trim());
                dataGridViewNhanVien.DataSource = a;
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonXoa_Click(object sender, EventArgs e)
        {
            try
            {
                String manv = dataGridViewThang.Rows[row2].Cells[0].Value.ToString(); 
                thang.delete(this.ngay,manv);
                this.load_luongthang();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonSua_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridViewNhanVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.row1 = e.RowIndex;
            try
            {
                String manv = dataGridViewNhanVien.Rows[row1].Cells[0].Value.ToString();
                String value1 = Interaction.InputBox("Nhập số ngày làm của nhân viên này", "Nhập ngày làm", "0", 500, 300);
                int soluong;
                soluong = Int32.Parse(value1);
                thang.insert(this.ngay, manv, soluong);
                this.load_luongthang();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridViewThang_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.row2 = e.RowIndex;
        }

        private void QLLuongThang_Load(object sender, EventArgs e)
        {
            DataTable data1 = new DataTable();
            
            data1 = thanhvien.showHoten();
            dataGridViewNhanVien.DataSource = data1;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            this.ngay = Convert.ToDateTime(dateTimePicker1.Value.ToString());
            load_luongthang();

        }

        public void load_luongthang()
        {
            DataTable a = new DataTable();
            a = thang.show_luong_thang(this.ngay);
            dataGridViewThang.DataSource = a;
        }

        private void buttonSua_Click_1(object sender, EventArgs e)
        {
            try
            {
                String manv = dataGridViewThang.Rows[row2].Cells[0].Value.ToString();
                String value1 = Interaction.InputBox("Nhập số ngày muốn sửa", "Sửa ngày làm", "0", 500, 300);
                int soluong;
                soluong = Int32.Parse(value1);
                thang.update(this.ngay, manv,soluong);
                this.load_luongthang();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridViewThang_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridViewNhanVien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void quảnLýThànhViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLnhanvien a = new QLnhanvien();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLHang a = new QLHang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThángLươngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLLuongThang a = new QLLuongThang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýNhậpHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLNhaphang a = new QLNhaphang();
            this.Hide();
            a.ShowDialog();
        }

        private void thốngKêToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thongke a = new Thongke();
            this.Hide();
            a.ShowDialog();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            this.Hide();
            a.ShowDialog();
        }

        private void thayĐổiTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thaydoimk a = new Thaydoimk();
            this.Hide();
            a.ShowDialog();
        }

        private void thiếtLậpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thietlap a = new Thietlap();
            this.Hide();
            a.ShowDialog();
        }

        private void trangChủToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Menutrip a = new Menutrip();
            this.Hide();
            a.ShowDialog();
        }
    }
}
