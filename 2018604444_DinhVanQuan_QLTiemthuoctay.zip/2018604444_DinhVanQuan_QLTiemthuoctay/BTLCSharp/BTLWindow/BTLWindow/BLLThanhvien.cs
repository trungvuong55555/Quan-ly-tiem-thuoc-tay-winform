﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace BTLWindow
{
    class BLLThanhvien
    {
        DAL data = new DAL();
        public DataTable selectThanhvien()
        {
            String sql = "select * from thanhvien";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }

        public DataTable showHoten()
        {
            String sql = "select matv,ten from thanhvien";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }

        public DataTable findHoten(String ten)
        {
            DataTable dt = new DataTable();
            if (ten.Equals("@all"))
            {
                String sql = "select matv,ten from thanhvien";

                dt = data.GetTable(sql);
                return dt;
            }
            else
            {
                String sql = "select matv,ten from thanhvien where ten ='" + ten + "'";

                dt = data.GetTable(sql);
                return dt;
            }
        }

        public void insertThanhVien(String matv, String ten, int tuoi,String que,int gioitinh,DateTime ngayvaolam)
        {
            String sql = "insert into thanhvien values('" + matv + "',N'" + ten + "'," + tuoi + ",N'" + que + "'," + gioitinh + ",'" + ngayvaolam.ToString("yyyy-MM-dd") + "')";
            data.ExecNonQuery(sql);
        }

        public void update(String matv, String ten, int tuoi, String que, int gioitinh, DateTime ngayvaolam)
        {
            String sql = "update thanhvien set ten= N'" + ten + "', tuoi=" + tuoi + ",que=N'" + que + "',gioitinh=" + gioitinh + ",ngayvaolam='" + ngayvaolam.ToString("yyyy-MM-dd") + "' where matv= '" + matv + "'";
            data.ExecNonQuery(sql);
        }

        public void delete(String matv)
        {
            String sql = "delete thanhvien where matv='" + matv + "'";
            data.ExecNonQuery(sql);
        }
    }
}
