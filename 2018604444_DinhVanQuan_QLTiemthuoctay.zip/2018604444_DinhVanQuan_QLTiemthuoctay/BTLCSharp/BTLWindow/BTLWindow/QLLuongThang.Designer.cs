﻿
namespace BTLWindow
{
    partial class QLLuongThang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridViewNhanVien = new System.Windows.Forms.DataGridView();
            this.ColumnMatv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBoxTimkiem = new System.Windows.Forms.TextBox();
            this.buttonTimkiem = new System.Windows.Forms.Button();
            this.dataGridViewThang = new System.Windows.Forms.DataGridView();
            this.ColumnDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMatv1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSongaylam = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnHoahong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonXoa = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonSua = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.trangChủToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýThànhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýThángLươngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýNhậpHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thiếtLậpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thayĐổiTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNhanVien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewThang)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(268, 97);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(360, 20);
            this.dateTimePicker1.TabIndex = 0;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(274, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(283, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "QUẢN LÝ LƯƠNG THÁNG";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(122, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Chọn tháng đại diện:";
            // 
            // dataGridViewNhanVien
            // 
            this.dataGridViewNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewNhanVien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnMatv,
            this.ColumnTen});
            this.dataGridViewNhanVien.Location = new System.Drawing.Point(0, 243);
            this.dataGridViewNhanVien.Name = "dataGridViewNhanVien";
            this.dataGridViewNhanVien.Size = new System.Drawing.Size(249, 150);
            this.dataGridViewNhanVien.TabIndex = 3;
            this.dataGridViewNhanVien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewNhanVien_CellClick);
            this.dataGridViewNhanVien.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewNhanVien_CellContentClick);
            // 
            // ColumnMatv
            // 
            this.ColumnMatv.DataPropertyName = "matv";
            this.ColumnMatv.HeaderText = "Mã nhân viên";
            this.ColumnMatv.Name = "ColumnMatv";
            // 
            // ColumnTen
            // 
            this.ColumnTen.DataPropertyName = "ten";
            this.ColumnTen.HeaderText = "Họ tên";
            this.ColumnTen.Name = "ColumnTen";
            // 
            // textBoxTimkiem
            // 
            this.textBoxTimkiem.Location = new System.Drawing.Point(12, 201);
            this.textBoxTimkiem.Name = "textBoxTimkiem";
            this.textBoxTimkiem.Size = new System.Drawing.Size(145, 20);
            this.textBoxTimkiem.TabIndex = 5;
            // 
            // buttonTimkiem
            // 
            this.buttonTimkiem.Location = new System.Drawing.Point(181, 197);
            this.buttonTimkiem.Name = "buttonTimkiem";
            this.buttonTimkiem.Size = new System.Drawing.Size(75, 23);
            this.buttonTimkiem.TabIndex = 6;
            this.buttonTimkiem.Text = "Tìm kiếm";
            this.buttonTimkiem.UseVisualStyleBackColor = true;
            this.buttonTimkiem.Click += new System.EventHandler(this.buttonTimkiem_Click);
            // 
            // dataGridViewThang
            // 
            this.dataGridViewThang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewThang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnDate,
            this.ColumnMatv1,
            this.ColumnSongaylam,
            this.ColumnLuong,
            this.ColumnHoahong,
            this.ColumnTong});
            this.dataGridViewThang.Location = new System.Drawing.Point(252, 243);
            this.dataGridViewThang.Name = "dataGridViewThang";
            this.dataGridViewThang.Size = new System.Drawing.Size(646, 150);
            this.dataGridViewThang.TabIndex = 7;
            this.dataGridViewThang.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewThang_CellClick);
            this.dataGridViewThang.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewThang_CellContentClick);
            // 
            // ColumnDate
            // 
            this.ColumnDate.DataPropertyName = "matv";
            this.ColumnDate.HeaderText = "Mã nhân viên";
            this.ColumnDate.Name = "ColumnDate";
            // 
            // ColumnMatv1
            // 
            this.ColumnMatv1.DataPropertyName = "hoten";
            this.ColumnMatv1.HeaderText = "Họ tên";
            this.ColumnMatv1.Name = "ColumnMatv1";
            // 
            // ColumnSongaylam
            // 
            this.ColumnSongaylam.DataPropertyName = "songaylam";
            this.ColumnSongaylam.HeaderText = "Số ngày làm";
            this.ColumnSongaylam.Name = "ColumnSongaylam";
            // 
            // ColumnLuong
            // 
            this.ColumnLuong.DataPropertyName = "luongthang";
            this.ColumnLuong.HeaderText = "Lương tháng";
            this.ColumnLuong.Name = "ColumnLuong";
            // 
            // ColumnHoahong
            // 
            this.ColumnHoahong.DataPropertyName = "hoahong";
            this.ColumnHoahong.HeaderText = "Hoa hồng";
            this.ColumnHoahong.Name = "ColumnHoahong";
            // 
            // ColumnTong
            // 
            this.ColumnTong.DataPropertyName = "tong";
            this.ColumnTong.HeaderText = "Tổng";
            this.ColumnTong.Name = "ColumnTong";
            // 
            // buttonXoa
            // 
            this.buttonXoa.Location = new System.Drawing.Point(655, 414);
            this.buttonXoa.Name = "buttonXoa";
            this.buttonXoa.Size = new System.Drawing.Size(75, 23);
            this.buttonXoa.TabIndex = 10;
            this.buttonXoa.Text = "Xóa";
            this.buttonXoa.UseVisualStyleBackColor = true;
            this.buttonXoa.Click += new System.EventHandler(this.buttonXoa_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(581, 201);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "THÔNG TIN";
            // 
            // buttonSua
            // 
            this.buttonSua.Location = new System.Drawing.Point(482, 414);
            this.buttonSua.Name = "buttonSua";
            this.buttonSua.Size = new System.Drawing.Size(75, 23);
            this.buttonSua.TabIndex = 12;
            this.buttonSua.Text = "Sửa";
            this.buttonSua.UseVisualStyleBackColor = true;
            this.buttonSua.Click += new System.EventHandler(this.buttonSua_Click_1);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trangChủToolStripMenuItem,
            this.quảnLýToolStripMenuItem,
            this.thiếtLậpToolStripMenuItem,
            this.thốngKêToolStripMenuItem,
            this.thayĐổiTàiKhoảnToolStripMenuItem,
            this.đăngXuấtToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(900, 24);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // trangChủToolStripMenuItem
            // 
            this.trangChủToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.trangChủToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.trangChủToolStripMenuItem.Name = "trangChủToolStripMenuItem";
            this.trangChủToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.trangChủToolStripMenuItem.Text = "Trang chủ";
            this.trangChủToolStripMenuItem.Click += new System.EventHandler(this.trangChủToolStripMenuItem_Click);
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.BackColor = System.Drawing.Color.Red;
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýThànhViênToolStripMenuItem,
            this.quảnLýHàngToolStripMenuItem,
            this.quảnLýThángLươngToolStripMenuItem,
            this.quảnLýNhậpHàngToolStripMenuItem});
            this.quảnLýToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.quảnLýToolStripMenuItem.Text = "Quản lý";
            // 
            // quảnLýThànhViênToolStripMenuItem
            // 
            this.quảnLýThànhViênToolStripMenuItem.Name = "quảnLýThànhViênToolStripMenuItem";
            this.quảnLýThànhViênToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.quảnLýThànhViênToolStripMenuItem.Text = "Quản lý thành viên";
            this.quảnLýThànhViênToolStripMenuItem.Click += new System.EventHandler(this.quảnLýThànhViênToolStripMenuItem_Click);
            // 
            // quảnLýHàngToolStripMenuItem
            // 
            this.quảnLýHàngToolStripMenuItem.Name = "quảnLýHàngToolStripMenuItem";
            this.quảnLýHàngToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.quảnLýHàngToolStripMenuItem.Text = "Quản lý hàng";
            this.quảnLýHàngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýHàngToolStripMenuItem_Click);
            // 
            // quảnLýThángLươngToolStripMenuItem
            // 
            this.quảnLýThángLươngToolStripMenuItem.Name = "quảnLýThángLươngToolStripMenuItem";
            this.quảnLýThángLươngToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.quảnLýThángLươngToolStripMenuItem.Text = "Quản lý tháng lương";
            this.quảnLýThángLươngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýThángLươngToolStripMenuItem_Click);
            // 
            // quảnLýNhậpHàngToolStripMenuItem
            // 
            this.quảnLýNhậpHàngToolStripMenuItem.Name = "quảnLýNhậpHàngToolStripMenuItem";
            this.quảnLýNhậpHàngToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.quảnLýNhậpHàngToolStripMenuItem.Text = "Quản lý nhập hàng";
            this.quảnLýNhậpHàngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýNhậpHàngToolStripMenuItem_Click);
            // 
            // thiếtLậpToolStripMenuItem
            // 
            this.thiếtLậpToolStripMenuItem.Name = "thiếtLậpToolStripMenuItem";
            this.thiếtLậpToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.thiếtLậpToolStripMenuItem.Text = "Thiết lập";
            this.thiếtLậpToolStripMenuItem.Click += new System.EventHandler(this.thiếtLậpToolStripMenuItem_Click);
            // 
            // thốngKêToolStripMenuItem
            // 
            this.thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            this.thốngKêToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.thốngKêToolStripMenuItem.Text = "Thống kê";
            this.thốngKêToolStripMenuItem.Click += new System.EventHandler(this.thốngKêToolStripMenuItem_Click);
            // 
            // thayĐổiTàiKhoảnToolStripMenuItem
            // 
            this.thayĐổiTàiKhoảnToolStripMenuItem.Name = "thayĐổiTàiKhoảnToolStripMenuItem";
            this.thayĐổiTàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(116, 20);
            this.thayĐổiTàiKhoảnToolStripMenuItem.Text = "Thay đổi tài khoản";
            this.thayĐổiTàiKhoảnToolStripMenuItem.Click += new System.EventHandler(this.thayĐổiTàiKhoảnToolStripMenuItem_Click);
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // QLLuongThang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 449);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.buttonSua);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonXoa);
            this.Controls.Add(this.dataGridViewThang);
            this.Controls.Add(this.buttonTimkiem);
            this.Controls.Add(this.textBoxTimkiem);
            this.Controls.Add(this.dataGridViewNhanVien);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Name = "QLLuongThang";
            this.Text = "QLLuongThang";
            this.Load += new System.EventHandler(this.QLLuongThang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNhanVien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewThang)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridViewNhanVien;
        private System.Windows.Forms.TextBox textBoxTimkiem;
        private System.Windows.Forms.Button buttonTimkiem;
        private System.Windows.Forms.DataGridView dataGridViewThang;
        private System.Windows.Forms.Button buttonXoa;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMatv;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTen;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonSua;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMatv1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSongaylam;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnHoahong;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTong;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem trangChủToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýThànhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýThángLươngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýNhậpHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thiếtLậpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thayĐổiTàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
    }
}