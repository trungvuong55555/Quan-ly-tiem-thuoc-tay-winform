﻿
namespace BTLWindow
{
    partial class User1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.bánHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thayĐổiMậtKhẩuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.buttonTongtien = new System.Windows.Forms.Button();
            this.buttonLuu = new System.Windows.Forms.Button();
            this.buttonLammoi = new System.Windows.Forms.Button();
            this.textBoxTongtien = new System.Windows.Forms.TextBox();
            this.dataGridViewHoadon = new System.Windows.Forms.DataGridView();
            this.ColumnMahoadon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMahang1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTenhang1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSoluongban = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnGiaban = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTongtien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateTimePickerNgaynhap = new System.Windows.Forms.DateTimePicker();
            this.textBoxMahoadon = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonTimkiemhang = new System.Windows.Forms.Button();
            this.textBoxTimkiemhang = new System.Windows.Forms.TextBox();
            this.dataGridViewHang = new System.Windows.Forms.DataGridView();
            this.ColumnMaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSoluong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHoadon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHang)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bánHàngToolStripMenuItem,
            this.thayĐổiMậtKhẩuToolStripMenuItem,
            this.đăngXuấtToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1029, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // bánHàngToolStripMenuItem
            // 
            this.bánHàngToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bánHàngToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bánHàngToolStripMenuItem.Name = "bánHàngToolStripMenuItem";
            this.bánHàngToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.bánHàngToolStripMenuItem.Text = "Bán hàng";
            // 
            // thayĐổiMậtKhẩuToolStripMenuItem
            // 
            this.thayĐổiMậtKhẩuToolStripMenuItem.Name = "thayĐổiMậtKhẩuToolStripMenuItem";
            this.thayĐổiMậtKhẩuToolStripMenuItem.Size = new System.Drawing.Size(117, 20);
            this.thayĐổiMậtKhẩuToolStripMenuItem.Text = "Thay đổi mật khẩu";
            this.thayĐổiMậtKhẩuToolStripMenuItem.Click += new System.EventHandler(this.thayĐổiMậtKhẩuToolStripMenuItem_Click);
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 24);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.buttonTongtien);
            this.splitContainer1.Panel1.Controls.Add(this.buttonLuu);
            this.splitContainer1.Panel1.Controls.Add(this.buttonLammoi);
            this.splitContainer1.Panel1.Controls.Add(this.textBoxTongtien);
            this.splitContainer1.Panel1.Controls.Add(this.dataGridViewHoadon);
            this.splitContainer1.Panel1.Controls.Add(this.dateTimePickerNgaynhap);
            this.splitContainer1.Panel1.Controls.Add(this.textBoxMahoadon);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.buttonTimkiemhang);
            this.splitContainer1.Panel2.Controls.Add(this.textBoxTimkiemhang);
            this.splitContainer1.Panel2.Controls.Add(this.dataGridViewHang);
            this.splitContainer1.Size = new System.Drawing.Size(1029, 551);
            this.splitContainer1.SplitterDistance = 698;
            this.splitContainer1.TabIndex = 1;
            // 
            // buttonTongtien
            // 
            this.buttonTongtien.Location = new System.Drawing.Point(97, 452);
            this.buttonTongtien.Name = "buttonTongtien";
            this.buttonTongtien.Size = new System.Drawing.Size(75, 23);
            this.buttonTongtien.TabIndex = 11;
            this.buttonTongtien.Text = "Tổng tiền:";
            this.buttonTongtien.UseVisualStyleBackColor = true;
            this.buttonTongtien.Click += new System.EventHandler(this.buttonTongtien_Click);
            // 
            // buttonLuu
            // 
            this.buttonLuu.Location = new System.Drawing.Point(403, 152);
            this.buttonLuu.Name = "buttonLuu";
            this.buttonLuu.Size = new System.Drawing.Size(75, 23);
            this.buttonLuu.TabIndex = 10;
            this.buttonLuu.Text = "Lưu mã";
            this.buttonLuu.UseVisualStyleBackColor = true;
            this.buttonLuu.Click += new System.EventHandler(this.buttonLuu_Click);
            // 
            // buttonLammoi
            // 
            this.buttonLammoi.BackColor = System.Drawing.Color.Blue;
            this.buttonLammoi.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonLammoi.Location = new System.Drawing.Point(244, 506);
            this.buttonLammoi.Name = "buttonLammoi";
            this.buttonLammoi.Size = new System.Drawing.Size(160, 32);
            this.buttonLammoi.TabIndex = 9;
            this.buttonLammoi.Text = "Làm mới";
            this.buttonLammoi.UseVisualStyleBackColor = false;
            this.buttonLammoi.Click += new System.EventHandler(this.buttonLammoi_Click);
            // 
            // textBoxTongtien
            // 
            this.textBoxTongtien.Location = new System.Drawing.Point(193, 452);
            this.textBoxTongtien.Name = "textBoxTongtien";
            this.textBoxTongtien.Size = new System.Drawing.Size(383, 20);
            this.textBoxTongtien.TabIndex = 7;
            // 
            // dataGridViewHoadon
            // 
            this.dataGridViewHoadon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHoadon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnMahoadon,
            this.ColumnMahang1,
            this.ColumnTenhang1,
            this.ColumnSoluongban,
            this.ColumnGiaban,
            this.ColumnTongtien});
            this.dataGridViewHoadon.Location = new System.Drawing.Point(0, 207);
            this.dataGridViewHoadon.Name = "dataGridViewHoadon";
            this.dataGridViewHoadon.Size = new System.Drawing.Size(683, 178);
            this.dataGridViewHoadon.TabIndex = 4;
            this.dataGridViewHoadon.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewHoadon_CellClick);
            this.dataGridViewHoadon.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewHoadon_CellContentClick);
            // 
            // ColumnMahoadon
            // 
            this.ColumnMahoadon.DataPropertyName = "mahoadon";
            this.ColumnMahoadon.HeaderText = "Mã hóa đơn";
            this.ColumnMahoadon.Name = "ColumnMahoadon";
            // 
            // ColumnMahang1
            // 
            this.ColumnMahang1.DataPropertyName = "mahang";
            this.ColumnMahang1.HeaderText = "Mã hàng";
            this.ColumnMahang1.Name = "ColumnMahang1";
            // 
            // ColumnTenhang1
            // 
            this.ColumnTenhang1.DataPropertyName = "tenhang";
            this.ColumnTenhang1.HeaderText = "Tên hàng";
            this.ColumnTenhang1.Name = "ColumnTenhang1";
            // 
            // ColumnSoluongban
            // 
            this.ColumnSoluongban.DataPropertyName = "soluong";
            this.ColumnSoluongban.HeaderText = "Số lượng";
            this.ColumnSoluongban.Name = "ColumnSoluongban";
            // 
            // ColumnGiaban
            // 
            this.ColumnGiaban.DataPropertyName = "giaban";
            this.ColumnGiaban.HeaderText = "Giá bán";
            this.ColumnGiaban.Name = "ColumnGiaban";
            // 
            // ColumnTongtien
            // 
            this.ColumnTongtien.DataPropertyName = "tongtien";
            this.ColumnTongtien.HeaderText = "Tổng tiền";
            this.ColumnTongtien.Name = "ColumnTongtien";
            // 
            // dateTimePickerNgaynhap
            // 
            this.dateTimePickerNgaynhap.Location = new System.Drawing.Point(137, 94);
            this.dateTimePickerNgaynhap.Name = "dateTimePickerNgaynhap";
            this.dateTimePickerNgaynhap.Size = new System.Drawing.Size(546, 20);
            this.dateTimePickerNgaynhap.TabIndex = 3;
            // 
            // textBoxMahoadon
            // 
            this.textBoxMahoadon.Location = new System.Drawing.Point(137, 24);
            this.textBoxMahoadon.Name = "textBoxMahoadon";
            this.textBoxMahoadon.Size = new System.Drawing.Size(546, 20);
            this.textBoxMahoadon.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ngày nhập:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã hóa đơn:";
            // 
            // buttonTimkiemhang
            // 
            this.buttonTimkiemhang.Location = new System.Drawing.Point(236, 503);
            this.buttonTimkiemhang.Name = "buttonTimkiemhang";
            this.buttonTimkiemhang.Size = new System.Drawing.Size(75, 23);
            this.buttonTimkiemhang.TabIndex = 2;
            this.buttonTimkiemhang.Text = "Tìm kiếm";
            this.buttonTimkiemhang.UseVisualStyleBackColor = true;
            this.buttonTimkiemhang.Click += new System.EventHandler(this.buttonTimkiemhang_Click);
            // 
            // textBoxTimkiemhang
            // 
            this.textBoxTimkiemhang.Location = new System.Drawing.Point(30, 506);
            this.textBoxTimkiemhang.Name = "textBoxTimkiemhang";
            this.textBoxTimkiemhang.Size = new System.Drawing.Size(188, 20);
            this.textBoxTimkiemhang.TabIndex = 1;
            // 
            // dataGridViewHang
            // 
            this.dataGridViewHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnMaHang,
            this.ColumnTenHang,
            this.ColumnSoluong});
            this.dataGridViewHang.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewHang.Name = "dataGridViewHang";
            this.dataGridViewHang.Size = new System.Drawing.Size(321, 470);
            this.dataGridViewHang.TabIndex = 0;
            this.dataGridViewHang.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewHang_CellClick);
            // 
            // ColumnMaHang
            // 
            this.ColumnMaHang.DataPropertyName = "mahang";
            this.ColumnMaHang.HeaderText = "Mã Hàng";
            this.ColumnMaHang.Name = "ColumnMaHang";
            // 
            // ColumnTenHang
            // 
            this.ColumnTenHang.DataPropertyName = "tenhang";
            this.ColumnTenHang.HeaderText = "Tên Hàng";
            this.ColumnTenHang.Name = "ColumnTenHang";
            // 
            // ColumnSoluong
            // 
            this.ColumnSoluong.DataPropertyName = "soluongco";
            this.ColumnSoluong.HeaderText = "Số lượng";
            this.ColumnSoluong.Name = "ColumnSoluong";
            // 
            // User1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1029, 575);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "User1";
            this.Text = "User1";
            this.Load += new System.EventHandler(this.User1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHoadon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHang)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem bánHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thayĐổiMậtKhẩuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button buttonLammoi;
        private System.Windows.Forms.TextBox textBoxTongtien;
        private System.Windows.Forms.DataGridView dataGridViewHoadon;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgaynhap;
        private System.Windows.Forms.TextBox textBoxMahoadon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonTimkiemhang;
        private System.Windows.Forms.TextBox textBoxTimkiemhang;
        private System.Windows.Forms.DataGridView dataGridViewHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSoluong;
        private System.Windows.Forms.Button buttonLuu;
        private System.Windows.Forms.Button buttonTongtien;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMahoadon;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMahang1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTenhang1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSoluongban;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnGiaban;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTongtien;
    }
}