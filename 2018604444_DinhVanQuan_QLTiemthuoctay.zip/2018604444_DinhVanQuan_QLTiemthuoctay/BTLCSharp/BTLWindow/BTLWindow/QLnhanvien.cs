﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTLWindow
{
    public partial class QLnhanvien : Form
    {
        BLLThanhvien thanhvien = new BLLThanhvien();
        BLLTaikhoan tk = new BLLTaikhoan();
        private int row;
        public QLnhanvien()
        {
            InitializeComponent();
        }

        private void buttonQuaylai_Click(object sender, EventArgs e)
        {
            Menu a = new Menu();
            a.Show();
            this.Close();
        }

        private void QLnhanvien_Load(object sender, EventArgs e)
        {
            DataTable a = new DataTable();
            a = thanhvien.selectThanhvien();
            dataGridView.DataSource = a;
        }

        


        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.row = e.RowIndex;
            try
            {
                textBoxManv.Text = dataGridView.Rows[row].Cells[0].Value.ToString();
                textBoxTen.Text = dataGridView.Rows[row].Cells[1].Value.ToString();
                textBoxTuoi.Text = dataGridView.Rows[row].Cells[2].Value.ToString();
                textBoxQuequan.Text = dataGridView.Rows[row].Cells[3].Value.ToString();
                String gioitinh = dataGridView.Rows[row].Cells[4].Value.ToString();
                if (gioitinh.Equals("0"))
                    radioButtonNu.Checked = true;
                else
                    radioButtonNam.Checked = true;
                dateTimePickerNgayvaolam.Value = Convert.ToDateTime(dataGridView.Rows[row].Cells[5].Value.ToString());


            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonThem_Click(object sender, EventArgs e)
        {
            try
            {
                int gioitinh = 0;
                if (radioButtonNam.Checked)
                    gioitinh = 1;
                thanhvien.insertThanhVien(textBoxManv.Text.Trim(), textBoxTen.Text.Trim(), Int32.Parse(textBoxTuoi.Text.Trim()), textBoxQuequan.Text.Trim(), gioitinh, dateTimePickerNgayvaolam.Value);
                this.QLnhanvien_Load(sender, e);
                tk.insert(textBoxManv.Text.Trim(), textBoxMatkhau.Text.Trim(), "nhanvien");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonSua_Click(object sender, EventArgs e)
        {
            try
            {
                int gioitinh = 0;
                if (radioButtonNam.Checked)
                    gioitinh = 1;
                thanhvien.update(textBoxManv.Text.Trim(), textBoxTen.Text.Trim(), Int32.Parse(textBoxTuoi.Text.Trim()), textBoxQuequan.Text.Trim(), gioitinh, dateTimePickerNgayvaolam.Value);
                this.QLnhanvien_Load(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonXoa_Click(object sender, EventArgs e)
        {
            try
            {
                thanhvien.delete(textBoxManv.Text.Trim());
                tk.delete(textBoxManv.Text.Trim());
                this.QLnhanvien_Load(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void trangChủToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Menutrip a = new Menutrip();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThànhViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLnhanvien a = new QLnhanvien();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLHang a = new QLHang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThángLươngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLLuongThang a = new QLLuongThang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýNhậpHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLNhaphang a = new QLNhaphang();
            this.Hide();
            a.ShowDialog();
        }

        private void thiếtLậpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thietlap a = new Thietlap();
            this.Hide();
            a.ShowDialog();
        }

        private void thốngKêToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thongke a = new Thongke();
            this.Hide();
            a.ShowDialog();
        }

        private void thayĐổiTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thaydoimk a = new Thaydoimk();
            this.Hide();
            a.ShowDialog();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            this.Hide();
            a.ShowDialog();
        }
    }
}
