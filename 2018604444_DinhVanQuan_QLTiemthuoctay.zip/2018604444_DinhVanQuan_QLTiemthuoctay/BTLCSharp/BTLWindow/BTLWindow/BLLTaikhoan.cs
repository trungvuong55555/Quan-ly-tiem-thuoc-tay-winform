﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace BTLWindow
{
    
    class BLLTaikhoan
    {
        DAL data = new DAL();
        public DataTable takeNhanvien()
        {
            String sql = "select ten,matkhau from taikhoan where chucvu='nhanvien'";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }

        public DataTable takeQuanly()
        {
            String sql = "select ten,matkhau from taikhoan where chucvu='quanly'";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }

        public void insert(String ten, String matkhau,String chucvu)
        {
            String sql = "insert into taikhoan values('" + ten + "','" + matkhau + "','" + chucvu + "')";
            data.ExecNonQuery(sql);
        }

        public void update_nhanvien(String ten, String matkhau)
        {
            String sql = "update taikhoan set matkhau ='" + matkhau + "' where ten='" + ten + "'";
            data.ExecNonQuery(sql);
        }

        public void update_quanly(String tencu, String matkhau, String tenmoi)
        {
            String sql = "update taikhoan set ten='"+tenmoi+"', matkhau='" + matkhau + "' where ten='" + tencu + "'";
            data.ExecNonQuery(sql);
        }

        public void delete(String ten)
        {
            String sql = "delete taikhoan where ten='" + ten + "'";
            data.ExecNonQuery(sql);
        }
    }
}
