﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTLWindow
{
    public partial class ThaydoimkNhanvien : Form
    {
        BLLTaikhoan t = new BLLTaikhoan();
        private String ten;
        public ThaydoimkNhanvien()
        {
            InitializeComponent();
        }

        public ThaydoimkNhanvien(String ten)
        {
            this.ten = ten;
            InitializeComponent();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            this.Hide();
            a.ShowDialog();
           
        }

        private void bánHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            User1 a = new User1(this.ten);
            this.Hide();
            a.ShowDialog();
            
        }

        public Boolean checkNhanVien(String ten, String matkhau)
        {
            DataTable data = t.takeNhanvien();
            foreach (DataRow i in data.Rows)
            {
                if (i["ten"].ToString().Equals(ten) && i["matkhau"].ToString().Equals(matkhau))
                    return true;
            }
            return false;
        }

        private void buttonThaydoi_Click(object sender, EventArgs e)
        {
            if (this.checkNhanVien(this.ten, textBoxMKcu.Text) == true)
            {
                if (textBoxMKmoi.Text.Equals(textBoxCheck.Text))
                {
                    t.update_nhanvien(this.ten, textBoxMKmoi.Text);
                    MessageBox.Show("Bạn đã thay đổi mật khẩu thành công!");
                }
                else
                    MessageBox.Show("Xác nhận sai mật khẩu mới!");
            }
            else
                MessageBox.Show("Sai mật khẩu!");
        }
    }
}
