﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTLWindow
{
    public partial class Thongke : Form
    {
        BLLQLLuongcoban lcb = new BLLQLLuongcoban();
        BLLNhap nhap = new BLLNhap();
        BLLQLThang thang = new BLLQLThang();
        private DateTime date;
        public Thongke()
        {
            InitializeComponent();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            /*this.date = dateTimePicker1.Value;
            DataTable data = new DataTable();
            data = lcb.getData();
            List<String> list = new List<String>();
            foreach (DataRow row in data.Rows)
            {
                String a = row[2].ToString();
                list.Add(a);
            }

            
            textBoxNha.Text = list[1];
            textBoxDiennuoc.Text = list[2];
            textBoxKhac.Text = list[3];
            DataTable data1 = new DataTable();
            DataTable data2 = new DataTable();
            DataTable data3 = new DataTable();
            DataTable data4 = new DataTable();
            DataTable data5 = new DataTable();
            data1 = thang.tong_tra_cong(this.date);//danh cho tra tien cong nhan vien
            data2 = nhap.tongnhap(this.date); // danh cho tong nhap trong thang do
            data3 = lcb.tongthu(this.date);//tong thu
            data4 = lcb.tongchi(this.date);
            data5 = lcb.tong(this.date);

            foreach (DataRow row in data1.Rows)
            {
                textBoxTracong.Text = row[0].ToString();
            }
            foreach (DataRow row in data2.Rows)
            {
                textBoxNhaphang.Text = row[0].ToString();
            }
            foreach (DataRow row in data3.Rows)
            {
                textBoxThu.Text = row[0].ToString();
            }
            foreach (DataRow row in data4.Rows)
            {
                textBoxChi.Text = row[0].ToString();
            }
            foreach (DataRow row in data5.Rows)
            {
                textBox8.Text = row[0].ToString();
            }*/

        }

        private void buttonQuaylai_Click(object sender, EventArgs e)
        {
            Menu a = new Menu();
            a.Show();
            this.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
           

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
          this.date = dateTimePicker1.Value;
          DataTable data = new DataTable();
          data = lcb.getData();
          List<String> list = new List<String>();
          foreach (DataRow row in data.Rows)
          {
              String a = row[2].ToString();
              list.Add(a);
          }
          textBoxNha.Text = list[1];
          textBoxDiennuoc.Text = list[2];
          textBoxKhac.Text = list[3];
          DataTable data1 = new DataTable();
          DataTable data2 = new DataTable();
          DataTable data3 = new DataTable();
          DataTable data4 = new DataTable();
          DataTable data5 = new DataTable();
          data1 = thang.tong_tra_cong(this.date);//danh cho tra tien cong nhan vien
          data2 = nhap.tongnhap(this.date); // danh cho tong nhap trong thang do
          data3 = lcb.tongthu(this.date);//tong thu
          data4 = lcb.tongchi(this.date);
          data5 = lcb.tong(this.date);

          foreach (DataRow row in data1.Rows)
          {
              textBoxTracong.Text = row[0].ToString();
          }
          foreach (DataRow row in data2.Rows)
          {
              textBoxNhaphang.Text = row[0].ToString();
          }
          foreach (DataRow row in data3.Rows)
          {
              textBoxThu.Text = row[0].ToString();
          }
          foreach (DataRow row in data4.Rows)
          {
              textBoxChi.Text = row[0].ToString();
          }
          foreach (DataRow row in data5.Rows)
          {
              textBox8.Text = row[0].ToString();
          }
        }

        private void trangChủToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Menutrip a = new Menutrip();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThànhViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLnhanvien a = new QLnhanvien();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLHang a = new QLHang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThángLươngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLLuongThang a = new QLLuongThang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýNhậpHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLNhaphang a = new QLNhaphang();
            this.Hide();
            a.ShowDialog();
        }

        private void thiếtLậpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thietlap a = new Thietlap();
            this.Hide();
            a.ShowDialog();
        }

        private void thốngKêToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thongke a = new Thongke();
            this.Hide();
            a.ShowDialog();
        }

        private void thayĐổiTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thaydoimk a = new Thaydoimk();
            this.Hide();
            a.ShowDialog();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            this.Hide();
            a.ShowDialog();
        }
    }
}
