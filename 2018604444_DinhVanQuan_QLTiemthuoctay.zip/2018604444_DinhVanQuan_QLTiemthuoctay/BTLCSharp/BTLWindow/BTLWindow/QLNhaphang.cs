﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTLWindow
{
    public partial class QLNhaphang : Form
    {
        BLLHang hang = new BLLHang();
        BLLNhap nhap = new BLLNhap();
        private int row1;
        private int row2;
        public QLNhaphang()
        {
            InitializeComponent();
        }

        private void buttonQuaylai_Click(object sender, EventArgs e)
        {
            Menu a = new Menu();
            a.Show();
            this.Close();
        }

        private void buttonThem_Click(object sender, EventArgs e)
        {
            try
            {
                nhap.insert(dateTimePickerNgaynhap.Value, textBoxMahang.Text.Trim(), Int32.Parse(textBoxSoluong.Text.Trim()), Int32.Parse(textBoxGianhap.Text.Trim()));
                this.load_data();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonSua_Click(object sender, EventArgs e)
        {
            try
            {
                nhap.update(dateTimePickerNgaynhap.Value, textBoxMahang.Text.Trim(), Int32.Parse(textBoxGianhap.Text.Trim()), Int32.Parse(textBoxSoluong.Text.Trim()));
                this.load_data();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonXoa_Click(object sender, EventArgs e)
        {
            try
            {
                nhap.delete(dateTimePickerNgaynhap.Value, textBoxMahang.Text.Trim());
                this.load_data();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable data = new DataTable();
            data = hang.findTenhang(textBoxTimkiem.Text);
            dataGridViewHang.DataSource = data;
        }

        public void load_data()
        {
            DataTable data1 = new DataTable();
            DataTable data2 = new DataTable();
            data1 = hang.showTenhang();
            dataGridViewHang.DataSource = data1;
            data2 = nhap.selectNhap();
            dataGridViewQLNhap.DataSource = data2;
        }

        private void dataGridViewHang_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.row1 = e.RowIndex;
            try
            {
                textBoxMahang.Text = dataGridViewHang.Rows[row1].Cells[0].Value.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void QLNhaphang_Load(object sender, EventArgs e)
        {
            this.load_data();
        }

        private void dataGridViewQLNhap_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            this.row2 = e.RowIndex;
            try
            {
                dateTimePickerNgaynhap.Value = Convert.ToDateTime(dataGridViewQLNhap.Rows[row2].Cells[0].Value.ToString());
                textBoxMahang.Text = dataGridViewQLNhap.Rows[row2].Cells[1].Value.ToString();
                textBoxSoluong.Text = dataGridViewQLNhap.Rows[row2].Cells[2].Value.ToString();
                textBoxGianhap.Text = dataGridViewQLNhap.Rows[row2].Cells[3].Value.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void trangChủToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Menutrip a = new Menutrip();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThànhViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLnhanvien a = new QLnhanvien();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLHang a = new QLHang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýThángLươngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLLuongThang a = new QLLuongThang();
            this.Hide();
            a.ShowDialog();
        }

        private void quảnLýNhậpHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QLNhaphang a = new QLNhaphang();
            this.Hide();
            a.ShowDialog();
        }

        private void thiếtLậpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thietlap a = new Thietlap();
            this.Hide();
            a.ShowDialog();
        }

        private void thốngKêToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thongke a = new Thongke();
            this.Hide();
            a.ShowDialog();
        }

        private void thayĐổiTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thaydoimk a = new Thaydoimk();
            this.Hide();
            a.ShowDialog();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            this.Hide();
            a.ShowDialog();
        }
    }
}
