﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace BTLWindow
{
    class BLLHang
    {
        DAL data = new DAL();

        public DataTable selectHang()
        {
            String sql = "select * from hang";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }

        public DataTable showTenhang()
        {
            String sql = "select mahang,tenhang,soluongco from hang";
            DataTable dt = new DataTable();
            dt = data.GetTable(sql);
            return dt;
        }

        public DataTable findTenhang(String tenhang)
        {
            try
            {
                DataTable dt = new DataTable();
                if (tenhang.Equals("@all")) 
                {

                    String sql = "select mahang,tenhang,soluongco from hang";
                    dt = data.GetTable(sql);
                    return dt; 
                }
                else
                {
                    String sql = "select mahang,tenhang,soluongco from hang where tenhang ='" + tenhang + "'";
                    dt = data.GetTable(sql);
                    return dt;
                }
            }catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }

        }

        public void delete(String mahang)
        {
            try
            {
                String sql = "delete hang where mahang='" + mahang + "'";
                data.ExecNonQuery(sql);
            }catch(SqlException ex )
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void update(String mahang, String tenhang, String nsx, DateTime hsd, int giaban)
        {
            try
            {
                String sql = "update hang set tenhang=N'" + tenhang + "',nsx=N'" + nsx + "',hsd='" + hsd.ToString("yyyy-MM-dd") + "',giaban=" + giaban + " where mahang='"+mahang+"'";
                data.ExecNonQuery(sql);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        public void insert(String mahang, String tenhang, String nsx, DateTime hsd, int giaban)
        {
            try
            {
                String sql = "insert into hang values('" + mahang + "',N'" + tenhang + "',N'" + nsx + "','" + hsd.ToString("yyyy-MM-dd") + "'," + giaban + ",0)";
                data.ExecNonQuery(sql);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
