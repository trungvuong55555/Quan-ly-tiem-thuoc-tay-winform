﻿
namespace BTLWindow
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.buttonQLNhanvien = new System.Windows.Forms.Button();
            this.buttonQLHang = new System.Windows.Forms.Button();
            this.buttonNhaphang = new System.Windows.Forms.Button();
            this.buttonQLLuongthang = new System.Windows.Forms.Button();
            this.buttonThongke = new System.Windows.Forms.Button();
            this.buttonThaydoimk = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.buttonThietlap = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "small_ror1496909863.jpg");
            // 
            // buttonQLNhanvien
            // 
            resources.ApplyResources(this.buttonQLNhanvien, "buttonQLNhanvien");
            this.buttonQLNhanvien.Name = "buttonQLNhanvien";
            this.buttonQLNhanvien.UseVisualStyleBackColor = true;
            this.buttonQLNhanvien.Click += new System.EventHandler(this.buttonQLNhanvien_Click);
            // 
            // buttonQLHang
            // 
            resources.ApplyResources(this.buttonQLHang, "buttonQLHang");
            this.buttonQLHang.Name = "buttonQLHang";
            this.buttonQLHang.UseVisualStyleBackColor = true;
            this.buttonQLHang.Click += new System.EventHandler(this.buttonQLHang_Click);
            // 
            // buttonNhaphang
            // 
            resources.ApplyResources(this.buttonNhaphang, "buttonNhaphang");
            this.buttonNhaphang.Name = "buttonNhaphang";
            this.buttonNhaphang.UseVisualStyleBackColor = true;
            this.buttonNhaphang.Click += new System.EventHandler(this.buttonNhaphang_Click);
            // 
            // buttonQLLuongthang
            // 
            resources.ApplyResources(this.buttonQLLuongthang, "buttonQLLuongthang");
            this.buttonQLLuongthang.Name = "buttonQLLuongthang";
            this.buttonQLLuongthang.UseVisualStyleBackColor = true;
            this.buttonQLLuongthang.Click += new System.EventHandler(this.buttonQLLuongthang_Click);
            // 
            // buttonThongke
            // 
            resources.ApplyResources(this.buttonThongke, "buttonThongke");
            this.buttonThongke.Name = "buttonThongke";
            this.buttonThongke.UseVisualStyleBackColor = true;
            this.buttonThongke.Click += new System.EventHandler(this.buttonThongke_Click);
            // 
            // buttonThaydoimk
            // 
            resources.ApplyResources(this.buttonThaydoimk, "buttonThaydoimk");
            this.buttonThaydoimk.Name = "buttonThaydoimk";
            this.buttonThaydoimk.UseVisualStyleBackColor = true;
            this.buttonThaydoimk.Click += new System.EventHandler(this.buttonThaydoimk_Click);
            // 
            // button7
            // 
            resources.ApplyResources(this.button7, "button7");
            this.button7.Name = "button7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // buttonThietlap
            // 
            resources.ApplyResources(this.buttonThietlap, "buttonThietlap");
            this.buttonThietlap.Name = "buttonThietlap";
            this.buttonThietlap.UseVisualStyleBackColor = true;
            this.buttonThietlap.Click += new System.EventHandler(this.buttonThietlap_Click);
            // 
            // Menu
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.buttonThietlap);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.buttonThaydoimk);
            this.Controls.Add(this.buttonThongke);
            this.Controls.Add(this.buttonQLLuongthang);
            this.Controls.Add(this.buttonNhaphang);
            this.Controls.Add(this.buttonQLHang);
            this.Controls.Add(this.buttonQLNhanvien);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button buttonQLNhanvien;
        private System.Windows.Forms.Button buttonQLHang;
        private System.Windows.Forms.Button buttonNhaphang;
        private System.Windows.Forms.Button buttonQLLuongthang;
        private System.Windows.Forms.Button buttonThongke;
        private System.Windows.Forms.Button buttonThaydoimk;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button buttonThietlap;
    }
}